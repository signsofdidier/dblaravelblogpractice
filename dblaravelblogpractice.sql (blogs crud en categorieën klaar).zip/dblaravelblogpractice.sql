-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 21 feb 2025 om 21:59
-- Serverversie: 8.3.0
-- PHP-versie: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dblaravelblogpractice`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_id` bigint UNSIGNED DEFAULT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blogs_photo_id_foreign` (`photo_id`),
  KEY `blogs_user_id_foreign` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `photo_id`, `user_id`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '🌿 Waarom minimalisme je leven kan veranderen', 16, 1, 'In een wereld vol prikkels en spullen kiezen steeds meer mensen voor minimalisme. Het gaat niet alleen om minder bezitten, maar vooral om meer leven. Door bewust te kiezen wat écht waarde heeft, creëer je ruimte — letterlijk én mentaal. Minder spullen betekent minder opruimen, minder stress en meer tijd voor de dingen die er écht toe doen. Begin klein: ruim een lade op, doneer kleding die je niet meer draagt. Je zult merken hoeveel rust dat geeft.', '2025-02-21 13:47:38', '2025-02-21 19:29:39', NULL),
(2, '☕ De magie van je ochtendroutine', 17, 1, 'Hoe je je ochtend begint, bepaalt vaak de toon voor de rest van je dag. Een sterke ochtendroutine kan je productiever, gelukkiger en rustiger maken. Sta iets eerder op, drink een glas water, beweeg tien minuten en schrijf kort je doelen op voor de dag. Voeg iets toe wat je gelukkig maakt, zoals lezen of meditatie. Het hoeft niet ingewikkeld te zijn — het gaat erom dat je de dag start met intentie.', '2025-02-21 13:47:38', '2025-02-21 18:55:47', NULL),
(3, '💡 Drie simpele hacks om productiever te werken', 18, 1, '1. De Pomodoro-techniek — Werk 25 minuten gefocust en neem daarna 5 minuten pauze. Na vier rondes een langere pauze. Zo houd je focus zonder uitgeput te raken.\r\n2. Begin met de moeilijkste taak — Ook wel “the frog” genoemd. Als je ’s ochtends de lastigste klus klaart, voelt de rest van de dag lichter.\r\n3. Minimaliseer afleidingen — Zet meldingen uit en gebruik apps als \"Focus To-Do\" om je geconcentreerd te houden.', '2025-02-21 13:47:38', '2025-02-21 20:02:19', NULL),
(7, '📚 Waarom lezen je superkracht is', 23, 1, 'In een tijdperk van snelle video’s en korte berichten lijkt lezen soms ouderwets, maar het blijft een van de krachtigste manieren om jezelf te ontwikkelen. Lezen stimuleert je creativiteit, verbetert je focus en vergroot je empathie. Of je nu duikt in een spannende thriller of een inspirerend non-fictieboek leest, je brein wordt geprikkeld op manieren die sociale media je niet kunnen bieden. Probeer eens 20 minuten per dag te lezen — je zult versteld staan van het effect.', '2025-02-21 20:05:29', '2025-02-21 20:05:29', NULL),
(8, '💻 Fullstack Developer worden?', 24, 1, 'Een fullstack developer beheerst zowel de front-end als de back-end van een applicatie. Begin met de basis van HTML, CSS en JavaScript. Kies daarna een front-end framework zoals React of Vue.js. Voor de back-end kun je werken met Node.js of Python (Django/Flask). Leer daarnaast databases zoals MySQL, PostgreSQL of MongoDB gebruiken. Met tools als Git en GitHub beheer je je code efficiënt. Bouw tot slot eigen projecten om je vaardigheden te tonen en een sterk portfolio op te bouwen. 🚀', '2025-02-21 20:13:20', '2025-02-21 20:13:20', NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'lifestyle', '2025-02-21 13:47:38', '2025-02-21 13:47:38'),
(2, 'health', '2025-02-21 13:47:38', '2025-02-21 13:47:38'),
(3, 'tech', '2025-02-21 13:47:38', '2025-02-21 13:47:38');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `category_blog`
--

DROP TABLE IF EXISTS `category_blog`;
CREATE TABLE IF NOT EXISTS `category_blog` (
  `blog_id` bigint UNSIGNED NOT NULL,
  `category_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `category_blog_blog_id_category_id_unique` (`blog_id`,`category_id`),
  KEY `category_blog_category_id_foreign` (`category_id`),
  KEY `category_blog_blog_id_category_id_index` (`blog_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `category_blog`
--

INSERT INTO `category_blog` (`blog_id`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL),
(1, 2, NULL, NULL),
(1, 3, NULL, NULL),
(2, 2, NULL, NULL),
(2, 3, NULL, NULL),
(3, 1, NULL, NULL),
(3, 3, NULL, NULL),
(7, 1, NULL, NULL),
(7, 2, NULL, NULL),
(7, 3, NULL, NULL),
(8, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000001_create_cache_table', 1),
(2, '0001_01_01_000002_create_jobs_table', 1),
(3, '2025_02_18_135109_create_roles_table', 1),
(4, '2025_02_18_140109_create_photos_table', 1),
(5, '2025_02_18_145109_create_users_table', 1),
(6, '2025_02_19_091658_create_role_user_table', 1),
(7, '2025_02_20_090108_create_blogs_table', 1),
(8, '2025_02_20_150327_create_categories_table', 1),
(9, '2025_02_20_152408_create_category_blog_table', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_text` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `path`, `alternate_text`, `created_at`, `updated_at`) VALUES
(1, 'https://placehold.co/640x480', 'Quo modi impedit sint eaque iusto recusandae et odit.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(3, 'https://placehold.co/640x480', 'Quia accusantium quo dignissimos aut in ea autem in.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(4, 'https://placehold.co/640x480', 'Eius quasi voluptas labore dignissimos sed.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(6, 'https://placehold.co/640x480', 'Quam explicabo consectetur consectetur.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(7, 'https://placehold.co/640x480', 'Fuga id aut consectetur minima eveniet.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(8, 'https://placehold.co/640x480', 'Dolorum repellendus officia corporis eum.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(10, 'https://placehold.co/640x480', 'Voluptatem modi corrupti aut ipsam sit quia.', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(16, 'blogs/34cc9878-4ab8-4a49-8576-c487edc0057d.jpg', '🌿 Waarom minimalisme je leven kan veranderen', '2025-02-21 18:55:08', '2025-02-21 18:56:08'),
(17, 'blogs/ea1922b5-8064-486f-9c9c-f51bd12d2da8.jpg', '☕ De magie van je ochtendroutine', '2025-02-21 18:55:47', '2025-02-21 18:55:47'),
(18, 'blogs/405513d4-2ba8-4383-8c93-2bd027a32b04.jpg', '💡 Drie simpele hacks om productiever te werken', '2025-02-21 18:56:40', '2025-02-21 18:56:40'),
(19, 'users/9fd1918d-12fb-4920-8ef7-a5f5058464be.jpg', 'Dimsum', '2025-02-21 19:05:48', '2025-02-21 19:05:48'),
(20, 'users/97d8be4e-7d68-411a-b7d0-b38f38e752b9.jpg', 'Didier', '2025-02-21 19:06:40', '2025-02-21 19:06:40'),
(22, 'users/5b4cb371-cdcf-462c-aefc-4590d7a9505b.jpg', 'Randy', '2025-02-21 20:03:26', '2025-02-21 20:03:26'),
(23, 'blogs/d8092d2b-b820-4164-9193-64c7b2cae40b.jpg', '📚 Waarom lezen je superkracht is', '2025-02-21 20:05:29', '2025-02-21 20:05:29'),
(24, 'blogs/d93da685-4413-407c-ab0f-2942eb872569.jpg', '💻 Fullstack Developer worden?', '2025-02-21 20:13:20', '2025-02-21 20:13:20');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(2, 'author', '2025-02-21 13:47:37', '2025-02-21 13:47:37'),
(3, 'subscriber', '2025-02-21 13:47:37', '2025-02-21 13:47:37');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `role_user`
--

DROP TABLE IF EXISTS `role_user`;
CREATE TABLE IF NOT EXISTS `role_user` (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `role_user_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  KEY `role_user_user_id_role_id_index` (`user_id`,`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, NULL),
(2, 3, NULL, NULL),
(3, 1, NULL, NULL),
(4, 1, NULL, NULL),
(4, 2, NULL, NULL),
(4, 3, NULL, NULL),
(5, 2, NULL, NULL),
(5, 3, NULL, NULL),
(6, 1, NULL, NULL),
(6, 3, NULL, NULL),
(7, 1, NULL, NULL),
(8, 1, NULL, NULL),
(8, 2, NULL, NULL),
(8, 3, NULL, NULL),
(9, 2, NULL, NULL),
(10, 1, NULL, NULL),
(10, 2, NULL, NULL),
(10, 3, NULL, NULL),
(11, 1, NULL, NULL),
(11, 2, NULL, NULL),
(11, 3, NULL, NULL),
(12, 2, NULL, NULL),
(13, 1, NULL, NULL),
(13, 2, NULL, NULL),
(13, 3, NULL, NULL),
(14, 3, NULL, NULL),
(15, 1, NULL, NULL),
(15, 3, NULL, NULL),
(16, 2, NULL, NULL),
(17, 1, NULL, NULL),
(17, 2, NULL, NULL),
(18, 1, NULL, NULL),
(18, 2, NULL, NULL),
(19, 2, NULL, NULL),
(20, 1, NULL, NULL),
(20, 2, NULL, NULL),
(21, 1, NULL, NULL),
(21, 2, NULL, NULL),
(21, 3, NULL, NULL),
(22, 2, NULL, NULL),
(23, 1, NULL, NULL),
(23, 2, NULL, NULL),
(23, 3, NULL, NULL),
(24, 2, NULL, NULL),
(24, 3, NULL, NULL),
(25, 1, NULL, NULL),
(25, 2, NULL, NULL),
(26, 2, NULL, NULL),
(27, 3, NULL, NULL),
(28, 2, NULL, NULL),
(28, 3, NULL, NULL),
(29, 1, NULL, NULL),
(29, 2, NULL, NULL),
(29, 3, NULL, NULL),
(30, 3, NULL, NULL),
(31, 1, NULL, NULL),
(31, 2, NULL, NULL),
(31, 3, NULL, NULL),
(32, 1, NULL, NULL),
(32, 2, NULL, NULL),
(32, 3, NULL, NULL),
(33, 2, NULL, NULL),
(34, 1, NULL, NULL),
(34, 2, NULL, NULL),
(34, 3, NULL, NULL),
(35, 1, NULL, NULL),
(35, 2, NULL, NULL),
(35, 3, NULL, NULL),
(36, 1, NULL, NULL),
(36, 2, NULL, NULL),
(37, 3, NULL, NULL),
(38, 3, NULL, NULL),
(39, 2, NULL, NULL),
(40, 3, NULL, NULL),
(41, 1, NULL, NULL),
(41, 2, NULL, NULL),
(41, 3, NULL, NULL),
(42, 2, NULL, NULL),
(43, 1, NULL, NULL),
(44, 2, NULL, NULL),
(44, 3, NULL, NULL),
(45, 2, NULL, NULL),
(46, 1, NULL, NULL),
(47, 2, NULL, NULL),
(48, 1, NULL, NULL),
(48, 2, NULL, NULL),
(48, 3, NULL, NULL),
(49, 1, NULL, NULL),
(49, 2, NULL, NULL),
(49, 3, NULL, NULL),
(50, 1, NULL, NULL),
(50, 2, NULL, NULL),
(50, 3, NULL, NULL),
(51, 1, NULL, NULL),
(51, 2, NULL, NULL),
(51, 3, NULL, NULL),
(52, 1, NULL, NULL),
(53, 1, NULL, NULL),
(53, 2, NULL, NULL),
(53, 3, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('ft1BrvSOAupmIOCs6842m80SFklBklTPOt49uJtm', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoicVBHN0xwQ2tLRkRORzJ6MGg0RWd3c040d2psZUxqOExKN1VmT0tVOSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM1OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYmFja2VuZC9ibG9ncyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', 1740172600);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` bigint UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_photo_id_foreign` (`photo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `photo_id`, `is_active`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 20, 1, 'Didier', 'didier.v@hotmail.com', '2025-02-21 13:47:37', '$2y$12$eFBXRhajn211PSIWR6ZC3uuNuUbduyYVgqTChwyH5T/oLZvHhGdmG', NULL, '2025-02-21 13:47:37', '2025-02-21 19:06:40', NULL),
(2, 7, 1, 'Melyssa Fadel V', 'swaniawski.tommie@example.org', '2025-02-21 13:47:37', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'BJSL65Mr3h', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(3, NULL, 1, 'Alejandra Dickens PhD', 'icie.kozey@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'XMZBDE4a45', '2025-02-21 13:47:38', '2025-02-21 14:14:09', '2025-02-21 14:14:09'),
(4, 1, 1, 'Mertie Kuhn', 'simeon.feeney@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '6TDaJm7Y7R', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(5, NULL, 0, 'Zack Bednar', 'adah69@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'QVt5uPOs6I', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(6, NULL, 1, 'Savion Ankunding I', 'gcrona@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'tbOMVt75Zj', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(7, NULL, 0, 'Prof. Terrill Prosacco', 'jaclyn84@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'BB3BBWER3d', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(8, NULL, 0, 'Lori Schmeler III', 'elmira.hansen@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'sSmay2hfcN', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(9, 3, 0, 'Julie Kunde MD', 'uschneider@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'aSpc9K5bIY', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(10, NULL, 0, 'Durward Hyatt', 'green52@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'Cidiyt035m', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(11, 1, 1, 'Prof. Devonte McGlynn', 'brant.lockman@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '8RC4g2GSMc', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(12, NULL, 0, 'Prof. Nella Brakus IV', 'ioberbrunner@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'xlkTea6EPH', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(13, 10, 1, 'Titus Leannon I', 'haley.lily@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'rjvsMbg6PX', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(14, 10, 1, 'Justice Vandervort', 'schimmel.moshe@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'oMy0fcVM7q', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(15, NULL, 0, 'Mr. Monserrate Huels I', 'vcrooks@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'Lm8X4lMF1t', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(16, 8, 1, 'Mr. Erin Wolff', 'flynch@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'qjnnBTpBtn', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(17, NULL, 1, 'Rusty Streich I', 'tfunk@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'qTivdRUPst', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(18, 1, 1, 'Ms. Providenci Nicolas II', 'dsanford@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'mdyQ1GpjpN', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(19, 3, 1, 'Prof. Aubree Will III', 'ktowne@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '8hfqvFQHFA', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(20, 7, 0, 'Prof. Sofia Hand Jr.', 'lind.alyce@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '6UYZ8AbPvK', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(21, NULL, 1, 'Prof. Amie Abbott IV', 'osvaldo62@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '4012XAieEp', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(22, NULL, 0, 'Maci Mayer', 'maya32@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'NHFx1H41kq', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(23, 8, 1, 'Miss Laurianne Johns', 'abshire.freddy@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'WBHo9MOWi6', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(24, 6, 1, 'Fannie Cummings', 'alva.blanda@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'iplWsFz5Ow', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(25, NULL, 0, 'Ryan VonRueden', 'terrill.towne@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'MQOJF77yYe', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(26, 7, 0, 'Beulah Stark', 'archibald.bergstrom@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'jM10GyVKY8', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(27, 3, 1, 'Jennings Walsh III', 'alverta15@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '4fQqtK3uEz', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(28, NULL, 0, 'Jules Konopelski', 'filiberto.kohler@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'z7UrtGclPf', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(29, NULL, 0, 'Shayne White', 'zander35@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'FVGDkTNv6W', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(30, 3, 0, 'Prof. Jacey Davis', 'elody.carroll@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'YrDLDkaIWY', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(31, 6, 0, 'Dr. Annabell Roberts', 'xhackett@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'MaiLyaRli1', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(32, 6, 1, 'Roscoe Nikolaus', 'xnienow@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '5PNlDrZ3O4', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(33, NULL, 1, 'Terence Schultz', 'eula.koch@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'gXPBZD0wNj', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(34, 8, 1, 'Annamae Quigley', 'schimmel.diego@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'H9viDDlV9O', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(35, 4, 1, 'Aliya Hickle', 'beth19@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'SWhea8orjG', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(36, 10, 0, 'Carlee Carter', 'jerrold.parker@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '8nWt3QdpBv', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(37, 4, 1, 'Everardo Abernathy', 'trent76@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'laISSB6a6x', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(38, 8, 0, 'Jairo Robel IV', 'weissnat.madge@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'Ls73iCF388', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(39, NULL, 1, 'Kaycee Lakin', 'amber78@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'eAFPXtfw2d', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(40, NULL, 0, 'Mr. Orion Schaden Jr.', 'richard.altenwerth@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'cKSCbKvZAQ', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(41, 1, 0, 'Brooks Buckridge', 'hermann.alford@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '5tmeFYV5pf', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(42, 4, 1, 'Daisha Waelchi', 'myrl15@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'WRrd73AAab', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(43, NULL, 1, 'Heather Frami', 'melany78@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'BxqU9qhm2p', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(44, NULL, 0, 'Dr. Bella Glover', 'ygibson@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'hGLswbX0rc', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(45, NULL, 1, 'Mason Harber', 'lester75@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'bH1UuLTAua', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(46, 8, 0, 'Dr. Ronaldo Gislason', 'schowalter.lue@example.org', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'DrBh9zjMRE', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(47, 4, 1, 'Nils Carter', 'wbalistreri@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '1W7yWfnUGc', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(48, 10, 1, 'Rico Leffler', 'carlee57@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'RlBmCRQC96', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(49, NULL, 1, 'Dr. Aracely Anderson', 'ines.kovacek@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'gGcSVE2zKc', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(50, NULL, 1, 'Heather Casper PhD', 'trace51@example.com', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', '08rAcOplLl', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(51, 4, 1, 'Nicolas O\'Hara', 'twalter@example.net', '2025-02-21 13:47:38', '$2y$12$eL/lHEZ0n9RJfmkd044ROO3R0A/AxWmfbxPmw8v9tEU81HWRv3Pia', 'JZbb57irac', '2025-02-21 13:47:38', '2025-02-21 13:47:38', NULL),
(52, 19, 1, 'Dimsum', 'dim@dum.sim', NULL, '$2y$12$2h46fVpBeUf7Y4lxNiGZQec2OZkQZy7lFvYbYcA1O8b1JuXBvYcP2', NULL, '2025-02-21 19:05:48', '2025-02-21 20:02:38', NULL),
(53, 22, 0, 'Randy', 'ran@dy.com', NULL, '$2y$12$URr.nR4r8GllQxQotCCO1eX0Gvld0ifcrBWPDiOvcsT5f3rFG.pT.', NULL, '2025-02-21 20:03:26', '2025-02-21 20:03:26', NULL);

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `blogs`
--
ALTER TABLE `blogs`
  ADD CONSTRAINT `blogs_photo_id_foreign` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `blogs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `category_blog`
--
ALTER TABLE `category_blog`
  ADD CONSTRAINT `category_blog_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_blog_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_photo_id_foreign` FOREIGN KEY (`photo_id`) REFERENCES `photos` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
